package com.amrita.jpl.cys21015.pract.general;

public class HelloWorld {

    /**
     * This class prints the "Hello, World!" message to the console.
     *
     * @author Dyanesh S [CB.EN.U4CYS21015]
     */

    public static void main(String[] args)
    {
        System.out.println("Hello, World!");
    }
}
