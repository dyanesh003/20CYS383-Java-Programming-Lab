package com.amrita.jpl.cys21015.pract.general;

public class PrintPattern {
}
